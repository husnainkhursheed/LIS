<footer class="footer border-top">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 text-center">
                 Privacy Statement
                            Legal Notices
                {{-- <script>document.write(new Date().getFullYear())</script> © Compliance. --}}
            </div>
            {{-- <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop by Zeta
                </div>
            </div> --}}
        </div>
    </div>
</footer>
